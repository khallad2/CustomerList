# CustomerList
    php:  7.3.8.
    composer: 1.9.0
    
#### if you have don't have composer installed on the machine no problem
#### the vendor directory contains the required package which is required to initiate communication
#### using slack webhooks

Creating new Slack Workspace 
### - please create workspace on slack
### - goto:  your-work-space.slack.com/apps/new/A0F7XDUAZ-incoming-webhooks 
### or goto: Browse apps --> Custom Integrations --> Incoming WebHooks
### - choose the desired channel to send your message to.
### - click add incoming Webhooks.
### - copy webhook URL and replace it with assigned value to $hookUrl="your-webhook-url" and Save. 

Run `php slack.php`

 

