<?php
// Mandatory: Please replace $hookUrl with your workspace hookUrl
// Optional: If you need Customization please replace 
//     $settings->username:  with the desired name as an app name
//     $settings->channel:   with channel name but keep #
require "./vendor/autoload.php";
class SlackService {
    // Properties
    public $client;
    public $sentMessage = "";
    public $hookUrl = "https://hooks.slack.com/services/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";
    public $settings = [
        "username" => "Media Partisan bot",
        "channel" => "#general",
    ];
    
    function __construct($msg) {
        $this->client = new Maknz\Slack\Client($this->hookUrl, $this->settings);    
        $this->sendSlackMessage($msg);
        $this->sentMessage = $msg;
    }
    
    function __destruct() {
        echo "This Message: {$this->sentMessage}.\n has been sent to slack successfully. \n";
    }

    private function sendSlackMessage($message) {
        $this->client->send($message);
    }    
}

$sendMsg = new SlackService("Hello Slack");
?>
